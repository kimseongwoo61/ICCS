from django.contrib import admin
from .models import Token_info


admin.site.register(Token_info)
# Register your models here.
